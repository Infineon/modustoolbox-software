#!/system/bin/sh
#
# Copyright (C) 2020, Cirrent Inc
#
# All use of this software must be covered by a license agreement signed by Cirrent Inc.
#
# DISCLAIMER. THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OR CONDITION,
# EXPRESS OR IMPLIED, INCLUDING BUT NOT LIMITED TO WARRANTIES OF MERCHANTABILITY,
# FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. LICENSORS HEREBY DISCLAIM
# ALL LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
# OUT OF OR IN CONNECTION WITH THE SOFTWARE.
#

set -x

: "${DIAGNOSTIC_ID:=$1}"
[ -n "$DIAGNOSTIC_ID" ] || exit 1
: "${DIAGNOSTIC_TYPE:=$2}"
[ -n "$DIAGNOSTIC_TYPE" ] || exit 1
: "${DIAGNOSTIC_INPUT_DATA:=$3}"
DIAGNOSTIC_RESULT_FILE="/sdcard/cirrent/diagnostic-${DIAGNOSTIC_TYPE}-${DIAGNOSTIC_ID}"

RESULT="FAILED"

rm "$DIAGNOSTIC_RESULT_FILE"
mkdir -p "/sdcard/cirrent"

date >> "$DIAGNOSTIC_RESULT_FILE"

case "$DIAGNOSTIC_TYPE" in
    "collect_logs")
        logcat -d -f "$DIAGNOSTIC_RESULT_FILE" && RESULT="SUCCESS"
        ;;
    *)
        echo "Unknown diagnostic type $DIAGNOSTIC_TYPE" >> "$DIAGNOSTIC_RESULT_FILE"
        ;;
esac

am broadcast -a com.cirrent.agent.SEND_DIAGNOSTIC_RESULT \
    -e id $DIAGNOSTIC_ID -e result $RESULT -e path $DIAGNOSTIC_RESULT_FILE

exit $?
